# t-rex-0.19.14

T-Rex v0.19.14 is the last version which supports Ritocoin's x21s algorithm.

The installation files are archived here in [Releases](releases).
